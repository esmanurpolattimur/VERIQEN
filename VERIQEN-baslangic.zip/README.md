# VERIQEN

**Otonom yapay zekâ ajanları için kanıt temelli ve risk uyarlamalı işlem denetimi**

*Verify Before You Execute.*

VERIQEN, bir yapay zekâ ajanının araç çağrısını işlem gerçekleşmeden önce değerlendirmek için tasarlanan bir güvenlik ara katmanıdır. Ajanın yetkisini, işlemi destekleyen kanıtı ve işlem riskini değerlendirir. Uygulama geliştiricisi, denetlenecek araç çağrılarını VERIQEN üzerinden yönlendirir.

## Örnek senaryo

Bir müşteri hizmetleri ajanı iade başlatmak ister. VERIQEN, siparişin iade uygunluğunu sipariş sisteminden doğrular ve tutarı iade politikasıyla karşılaştırır.

| Karar | Sonuç |
| --- | --- |
| `ALLOW` | Yetki ve kanıt koşulları karşılanır. İşlem otomatik yürütülebilir. |
| `REVIEW` | İşlem bekletilir ve yetkili bir kişiye inceleme için yönlendirilir. |
| `BLOCK` | İşlem politika ihlali nedeniyle durdurulur. |

## Proje durumu

Proje tasarım ve araştırma aşamasındadır. İlk prototip için FastAPI tabanlı bir karar servisi, yerel sipariş simülatörü ve GPU gerektirmeyen sentetik test senaryoları planlanıyor. Teknik özgünlük ve deneysel üstünlük araştırma hipotezleridir.

## Dokümantasyon

- [Teknik mimari](docs/architecture.md)
- [Araştırma ve deney planı](docs/evaluation-plan.md)
