# Araştırma ve deney planı

## Hipotez

Yetki ve zorunlu kanıt denetimini sabit tutup ek doğrulamayı işlem riskine göre seçmek, her vakada aynı ek kontrolleri çalıştıran bir politikaya kıyasla güvensiz işlemlerin yürütülme oranını artırmadan doğrulama yükünü azaltabilir. Hipotez henüz sınanmadı.

Özgünlük taraması, işlem parametrelerine bağlanan yetkilendirme, yürütme anında kanıt tazeliği ve riske göre seçilen doğrulama adımları üzerine odaklanacak. En yakın çalışmaların karar kuralları, varsayımları ve deney koşulları karşılaştırılacak.

## Karşılaştırma

| Yöntem | Karar mekanizması |
| --- | --- |
| B0 | Korumasız ajan. Yalnızca simülatörde çalıştırılır. |
| B1 | Sabit yetki kuralları. |
| B2 | Dil modeliyle karar değerlendirmesi. |
| B3 | Yetki ve zorunlu kanıt kontrolü, sabit ek doğrulama. |
| B4 | B3 ile aynı yetki ve zorunlu kanıt kontrolü, riske göre seçilen ek doğrulama. |

B3 ve B4 aynı kanıt kaynaklarını, kesin yetki sınırlarını ve inceleme kurallarını kullanacak. B2 bulut modeli kullanırsa model, istem, sağlanan kanıt ve API çağrı maliyeti kaydedilecek.

## Senaryolar ve ölçüm

- Geçerli düşük riskli işlem, insan onayı gerektiren işlem ve kesin yetki ihlali.
- Eksik, çelişkili, güncelliğini yitirmiş veya ajan tarafından uydurulmuş kanıt.
- Değişen sipariş sürümü, yinelenen istek ve doğrulama kaynağı kesintisi.

Her vakada beklenen karar ve işlemin yürütülüp yürütülemeyeceği testten önce etiketlenecek. Eşik ayarlama vakaları test vakalarından ayrılacak. Tüm yöntemler aynı test setinde çalıştırılacak.

Güvensiz işlem yürütme oranı, güvenli işlemlerin yanlış engellenme oranı, insan incelemesi oranı, doğrulama çağrısı sayısı ve p50/p95 karar gecikmesi raporlanacak. Bulgular eşleştirilmiş vakalar üzerinden karşılaştırılacak. Güvenlik farkı için kabul eşiği testten önce belirlenecek.

İlk deneyler sentetik verilerle ve yerel CPU üzerinde yürütülecek.
