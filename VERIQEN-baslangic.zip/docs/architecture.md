# Teknik mimari

Bu belge ilk prototipin önerilen tasarımını açıklar. Örnek akış sentetik sipariş verileriyle çalışacak bir iade simülatörüdür.

```mermaid
flowchart LR
    A["Ajan"] --> G["VERIQEN API"]
    G --> P["Karar motoru"]
    P --> S["Sipariş sistemi"]
    P --> D{"Karar"}
    D -->|ALLOW| X["İade yürütücüsü"]
    D -->|REVIEW| H["İnsan incelemesi"]
    D -->|BLOCK| B["İşlemi durdur"]
```

## İşlem isteği

Ajan işlem türünü, sipariş kimliğini, tutarı ve para birimini iletir. Sunucu ajan kimliğini kimlik doğrulama bağlamından alır. Sipariş durumu, iade edilebilir tutar ve kayıt sürümü sipariş sisteminden alınır. Ajanın beyan ettiği değerler doğrulama girdisidir.

## Karar kuralları

1. Yasak işlem türü, kesin yetki sınırının aşılması veya doğrulanmış politika ihlali `BLOCK` üretir.
2. Zorunlu kanıt eksikse veya kaynağa ulaşılamıyorsa işlem otomatik yürütülmez. İncelemeyle giderilebilen durumlar `REVIEW` alır.
3. Otomatik iade eşiği ile kesin yetki sınırı ayrı politika değerleridir. Aradaki tutarlar ek kanıt ve yetkili insan incelemesi gerektirir.
4. `ALLOW`, yalnızca işlemin zorunlu yetki, kanıt ve risk koşulları karşılandığında verilir.

## Yürütme sınırı

Ajan yalnızca denetimli aracı çağırır. İade simülatörünün yazma yetkisi yürütücüye aittir. Yürütücü izin verilen işlem parametrelerini ve sipariş sürümünü yürütmeden önce kontrol eder. Aynı işlem kimliğiyle yinelenen istekler ikinci iade üretmez. İnceleme sonrasında parametreler veya sipariş durumu değişirse karar yeniden değerlendirilir.

Denetim kaydı işlem kimliğini, karar gerekçesini, politika sürümünü ve kullanılan kanıt kaydının kimliğini içerir. İlk prototipin kabul ölçütü, izinli, inceleme gerektiren ve engellenen üç senaryonun uçtan uca yerel olarak gösterilmesidir.
